<div id="accueil" class="container-fluid">

    <div class="row">
        <header class="page-header">
            <img class="img-responsive" src="media/logo_br_clair.png" alt="Logo Benjamin Répécaud" width="20%">
        </header>        
        <!--<div class="col-lg-12">
            <img class="img-responsive" src="media/logo_br_clair.png" alt="Logo Benjamin Répécaud" width="20%">
        </div>-->
        <div class="col-lg-12 text-center">
            Bienvenue - Welcome - Bienvenido - Bem-vindo
        </div>
        <div class="col-lg-12">
            <a class="btn btn-block" href="#presentation" role="button">Bas</a>
        </div>
    </div>
</div>