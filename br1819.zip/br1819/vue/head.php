<head>
    <meta charset="UTF-8">
    <meta content="author" name="Benjamin Répécaud">
    <meta content="description" name="Portfolio">
    <meta name="viewport" content="width=device-width, initial-scale=1">    
    <title>Benjamin Répécaud</title>
    
    <!-- STYLE / SCRIPT -->
    <link rel="stylesheet" href="style/style.css">
    
    <!-- CDN -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
    <link href="https://fonts.googleapis.com/css?family=Righteous" rel="stylesheet">
    

</head>