<div id="contact" class="container-fluid">
    <div class="row">
        <!--------------------------------HEADER--> 
        <header class="page-header">
            <h2>Contact</h2>
        </header>        
        <div class="col-lg-5">
            <div class="col-lg-4">Picto</div>
            <div class="col-lg-8">mail</div>
            <div class="col-lg-4">Picto</div>
            <div class="col-lg-8">telephone</div>
            <div class="col-lg-4">Picto</div>
            <div class="col-lg-8">linkedin</div>
            <div class="col-lg-4">Picto</div>
            <div class="col-lg-8">GitHub</div>
        </div>
        <div class="col-lg-2">
            Barre
        </div>
        <div class="col-lg-5">
            <form>
                <!----------------------------------------------------NOM/PRENOM-->                 
                <div class="form-group col-lg-5">
                    <input type="text" class="form-control col-lg-5" placeholder="Nom" name="nom">
                </div>
                
                <div class="form-group col-lg-5">
                    <input type="text" class="form-control col-lg-5" placeholder="Prénom" name="prenom">
                </div>
                
                <!----------------------------------------------------EMAIL-->                 
                <div class="form-group">
                    <input type="email" class="form-control" placeholder="Email" name="email">
                </div>
                <!----------------------------------------------------OBJET-->                 
                <div class="form-group col-lg-5">
                    <input type="text" class="form-control" placeholder="Objet" name="objet">
                </div>
                <!----------------------------------------------------MESSAGE-->                 
                <div class="form-group">
                    <textarea class="form-control" rows="3" placeholder="Message"></textarea>
                </div>
                <button type="submit" class="btn">Envoyer</button>
            </form>
        </div>
    </div>
</div>

