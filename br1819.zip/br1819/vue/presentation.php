<div id="presentation" class="container-fluid">

<!--------------------------------LIGNE--> 
    <div class="row">
        <header class="page-header">
            <h2>Présentation</h2>
        </header>
        <!--<div class="col-lg-1">
            Présentation
        </div>-->
        <div class="col-lg-offset-1 col-lg-10">
            <div class="row">
                <div class="panel col-lg-12">
                    <!----------------------------------------------------PANNEAU de PRESENTATION--> 
                    <!--------------------------------Titre--> 
                    <div class="panel-heading">
                        Benjamin Répécaud
                    </div>
                    <!--------------------------------Corps du panneau--> 
                    <div class="panel-body">
                        <ul class="list-group">
                            <li class="list-group-item">21 ans</li>
                            <li class="list-group-item">Etudiant en Licence Informatique</li>
                            <li class="list-group-item">DEUG Informatique</li>
                            <li class="list-group-item">DUT MMI</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4">
                    <button type="button" class="btn-warning">CV</button>
                </div>
                <div class="col-lg-offset-4 col-lg-4">
                    <button type="button" class="btn-warning">PROJETS</button>
                </div>
            </div>
        </div>
    </div>
</div>