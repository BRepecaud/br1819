<?php
//------------CONTROLEUR
    include('vue/menu.php');
?>