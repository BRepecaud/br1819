<?php
//------------CONTROLEUR
    //include('modele/projets.php');
    include('vue/projets.php');
?>