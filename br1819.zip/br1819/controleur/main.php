<?php
//------------CONTROLEUR
    include('vue/main.php');
    include('vue/presentation.php');
    include('vue/contact.php');
?>